<?php

// DADOS DA HOSPEDAGEM PARA O ENVIO DE EMAILS

define("MAIL", [
   "host" => "", // HOST
   "port" => "", // PORTA SMTP OU IMAP
   "user" => "", // USUÁRIO
   "passwd" => "", // SENHA
   "from_name" => "", // QUEM ESTÁ ENVIANDO
   "from_email" => "" // EMAIL ESCOLHIDO PARA O RECEBIMENTO DAS MENSAGENS
]);
