<?php

// DADOS DA HOSPEDAGEM PARA O ENVIO DE EMAILS

define("MAIL", [
   "host" => "mail.stalloscabeleireiros.com.br", // HOST
   "port" => "465", // PORTA SMTP OU IMAP
   "user" => "envio@stalloscabeleireiros.com.br", // USUÁRIO
   "passwd" => "stal@envio@", // SENHA
   "from_name" => "Stallos Cabeleireiro", // ASSUNTO
   "from_email" => "envio@stalloscabeleireiros.com.br" // EMAIL ESCOLHIDO PARA O RECEBIMENTO DAS MENSAGENS
]);